#!/bin/bash
python ./generateSummary.py > summary-trace-znn.log 